import numpy as np
from matplotlib import pyplot as plt

#a) homework a
x_an = np.loadtxt("homework_a_nozzle.txt")[0]
Mx_an = np.loadtxt("homework_a_nozzle.txt")[1]
px_an = np.loadtxt("homework_a_nozzle.txt")[2]

x_ad = np.loadtxt("homework_a_duct.txt")[0]
Mx_ad = np.loadtxt("homework_a_duct.txt")[1]
px_ad = np.loadtxt("homework_a_duct.txt")[2]
pox_ad = np.loadtxt("homework_a_duct.txt")[3]

#b) homework b

x_bn = np.loadtxt("homework_b_nozzle.txt")[0]
Mx_bn = np.loadtxt("homework_b_nozzle.txt")[1]
px_bn = np.loadtxt("homework_b_nozzle.txt")[2]

x_bd = np.loadtxt("homework_b_duct.txt")[0]
Mx_bd = np.loadtxt("homework_b_duct.txt")[1]
px_bd = np.loadtxt("homework_b_duct.txt")[2]
pox_bd = np.loadtxt("homework_b_duct.txt")[3]

#c) homework c

x_cn = np.loadtxt("homework_c_nozzle.txt")[0]
Mx_cn = np.loadtxt("homework_c_nozzle.txt")[1]
px_cn = np.loadtxt("homework_c_nozzle.txt")[2]

x_cd = np.loadtxt("homework_c_duct.txt")[0]
Mx_cd = np.loadtxt("homework_c_duct.txt")[1]
px_cd = np.loadtxt("homework_c_duct.txt")[2]
pox_cd = np.loadtxt("homework_c_duct.txt")[3]

"""
Do nice plots
"""
